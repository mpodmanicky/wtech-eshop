<div class="paymentConfirmation">
  <h1>Payment Confirmation</h1>
  <p>Thank you, <?php echo e($name); ?>!</p>
  <p>Your email address: <?php echo e($email); ?></p>
  <p>Your address: <?php echo e($address); ?></p>

  <?php if(isset($cart) && !empty($cart)): ?>
    <h2>Your Cart Items</h2>
    <ul>
      <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($item['name']); ?> - <?php echo e($item['price']); ?>€</li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  <?php endif; ?>

  <h2>Transportation</h2>
  <p><?php echo e($transportation); ?></p>  <h2>Payment Method</h2>
  <p><?php echo e($payment); ?></p>        </div><?php /**PATH /Users/martinpodmanicky/Desktop/wtech-eshop/sforzando/resources/views/payment-confirmation.blade.php ENDPATH**/ ?>