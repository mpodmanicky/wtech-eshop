<!--Made by Martin Podmanicky, Dominik Tulach-->

<!DOCTYPE html>
<html>
<head>
    <title>Admin Form</title>
</head>
<body>
    <h2>Admin Form</h2>
    <form>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>
        
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>
        
        <input type="submit" value="Login">
    </form>
</body>
</html>